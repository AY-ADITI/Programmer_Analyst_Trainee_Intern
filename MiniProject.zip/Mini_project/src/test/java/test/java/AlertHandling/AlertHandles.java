package test.java.AlertHandling;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AlertHandles {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("http://demo.automationtesting.in/Alerts.html");
    }

    @Test(priority = 1)
    public void testAlertWithOK() throws InterruptedException {
        driver.findElement(By.partialLinkText("Alert with OK")).click();
        driver.findElement(By.cssSelector(".btn-danger")).click();
        Alert alert1 = driver.switchTo().alert();
        Thread.sleep(2000);
        alert1.accept();
    }

    @Test(priority = 2)
    public void testAlertWithOKCancel() throws InterruptedException {
        driver.findElement(By.partialLinkText("OK & Cancel")).click();
        driver.findElement(By.cssSelector(".btn-primary")).click();
        Alert alert2 = driver.switchTo().alert();
        Thread.sleep(2000);
        alert2.dismiss(); // Press Cancel
        WebElement para = driver.findElement(By.id("demo"));
        System.out.println("Section 2 Result: " + para.getText());
    }

    @Test(priority = 3)
    public void testAlertWithTextbox() throws InterruptedException {
        driver.findElement(By.partialLinkText("Textbox")).click();
        driver.findElement(By.cssSelector(".btn-info")).click();
        Alert alert3 = driver.switchTo().alert();
        alert3.sendKeys("Aditi Yadav");
        Thread.sleep(2000);
        alert3.accept();
        WebElement para1 = driver.findElement(By.id("demo1"));
        System.out.println("Section 3 Result: " + para1.getText());
        Thread.sleep(2000);
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}


