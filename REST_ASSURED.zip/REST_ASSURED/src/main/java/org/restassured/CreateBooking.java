package org.restassured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CreateBooking {
    public static void main(String[] args) {

        String requestBody = "{\n" +
                "    \"firstname\" : \"Adam\",\n" +
                "    \"lastname\" : \"Gill\",\n" +
                "    \"totalprice\" : 111,\n" +
                "    \"depositpaid\" : true,\n" +
                "    \"bookingdates\" : {\n" +
                "        \"checkin\" : \"2026-01-01\",\n" +
                "        \"checkout\" : \"2026-01-01\"\n" +
                "    },\n" +
                "    \"additionalneeds\" : \"Lunch\"\n" +
                "}";

        String baseURI = "https://restful-booker.herokuapp.com";


        Response response =
                given()
                        .header("Accept", "application/json")     // required for proper response
                        .contentType(ContentType.JSON)
                        .body(requestBody)
                        .when().log().all()
                        .post("/booking")
                        .then()
                        .log().all()
                        .statusCode(200)                          // POST /booking always returns 200
                        .body("booking.firstname", equalTo("Adam"))
                        .body("booking.lastname", equalTo("Gill"))
                        .extract().response();

        System.out.println("\nCreated Booking Response:\n" + response.asPrettyString());
    }
}
